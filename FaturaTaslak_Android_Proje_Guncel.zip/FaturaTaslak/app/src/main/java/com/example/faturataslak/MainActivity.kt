package com.example.faturataslak

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val tr = Locale("tr", "TR")
    private val money = NumberFormat.getNumberInstance(tr).apply { minimumFractionDigits = 2; maximumFractionDigits = 2 }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        findViewById<Button>(R.id.hesapla).setOnClickListener { calculate() }
        findViewById<Button>(R.id.pdf).setOnClickListener { createPdf() }
        calculate()
    }

    private fun d(id: Int): Double = findViewById<EditText>(id).text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0

    private fun calculate() {
        var subtotal = 0.0
        val rows = listOf(
            Pair(R.id.miktar1, R.id.fiyat1), Pair(R.id.miktar2, R.id.fiyat2),
            Pair(R.id.miktar3, R.id.fiyat3), Pair(R.id.miktar4, R.id.fiyat4), Pair(R.id.miktar5, R.id.fiyat5)
        )
        rows.forEach { subtotal += d(it.first) * d(it.second) }
        val vat = subtotal * d(R.id.kdv) / 100.0
        findViewById<TextView>(R.id.toplam).text = "Ara toplam: ${money.format(subtotal)} TL\nKDV: ${money.format(vat)} TL\nGenel toplam: ${money.format(subtotal + vat)} TL"
    }

    private fun text(id: Int) = findViewById<EditText>(id).text.toString().trim()

    private fun createPdf() {
        calculate()
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.BLACK
        p.textSize = 12f
        p.typeface = Typeface.DEFAULT_BOLD
        c.drawText("FATURA TASLAĞI", 36f, 42f, p)
        p.color = Color.rgb(190, 0, 0)
        p.textSize = 10f
        c.drawText("TASLAK / ÖRNEKTİR – RESMİ FATURA DEĞİLDİR", 36f, 60f, p)
        p.color = Color.BLACK
        p.typeface = Typeface.DEFAULT
        p.textSize = 10f
        var y = 88f
        val lines = listOf(
            "Alıcı: ${text(R.id.alici)}",
            "Adres: ${text(R.id.adres)}",
            "Vergi Dairesi: ${text(R.id.vergiDairesi)}    VKN: ${text(R.id.vkn)}",
            "Fatura No: ${text(R.id.faturaNo)}    Tarih: ${text(R.id.faturaTarihi)}"
        )
        lines.forEach { c.drawText(it, 36f, y, p); y += 17f }
        y += 12f
        p.typeface = Typeface.DEFAULT_BOLD
        c.drawText("Sıra", 36f, y, p); c.drawText("Ürün / Hizmet", 70f, y, p); c.drawText("Miktar", 330f, y, p); c.drawText("Birim", 390f, y, p); c.drawText("Tutar", 470f, y, p)
        y += 8f
        c.drawLine(32f, y, 560f, y, p); y += 20f
        p.typeface = Typeface.DEFAULT
        val productIds = listOf(R.id.urun1, R.id.urun2, R.id.urun3, R.id.urun4, R.id.urun5)
        val qtyIds = listOf(R.id.miktar1, R.id.miktar2, R.id.miktar3, R.id.miktar4, R.id.miktar5)
        val priceIds = listOf(R.id.fiyat1, R.id.fiyat2, R.id.fiyat3, R.id.fiyat4, R.id.fiyat5)
        for (i in 0..4) {
            val name = text(productIds[i]); if (name.isBlank()) continue
            val qty = d(qtyIds[i]); val price = d(priceIds[i]); val total = qty * price
            c.drawText("${i + 1}", 36f, y, p); c.drawText(name.take(38), 70f, y, p); c.drawText(money.format(qty), 330f, y, p); c.drawText(money.format(price), 390f, y, p); c.drawText(money.format(total), 470f, y, p); y += 22f
        }
        y += 18f
        c.drawLine(300f, y, 560f, y, p); y += 22f
        val totalText = findViewById<TextView>(R.id.toplam).text.toString().split("\n")
        totalText.forEach { c.drawText(it, 330f, y, p); y += 18f }
        y += 12f
        c.drawText("Not: Bu belge yalnızca taslak/örnek amaçlıdır ve resmi fatura değildir.", 36f, y, p)
        doc.finishPage(page)
        val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
        val file = File(dir, "fatura_taslak.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        Toast.makeText(this, "PDF hazır: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }
}
